<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $path = $_SERVER['REQUEST_URI'] ?: $_SERVER['PATH_INFO'];
    $file = sprintf('/var/www/vendor/bin/%s %s', $path == '/scheduled' ? 'cron-runner' : 'script-runner', file_get_contents('php://input'));
    $cmd  = sprintf('%s > /var/log/run.log 2>&1 &', $file);

    file_put_contents('/var/log/daemon.log', sprintf("%s - %s\n", @date('Y-m-d H:i:s'), $cmd), FILE_APPEND);

    chdir('/var/www');
    exec($cmd);
}
